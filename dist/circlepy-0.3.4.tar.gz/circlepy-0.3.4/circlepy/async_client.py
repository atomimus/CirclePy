

class AsyncCircleClient:
    def __init__(self, *args, **kwargs):
        raise NotImplementedError